class TollCalculator:
    def __init__(self, rate_per_meter):
        self.rate_per_meter = rate_per_meter

    def calculate_toll(self, distance):
        return distance * self.rate_per_meter

# Example usage:
toll_calculator = TollCalculator(rate_per_meter=0.05)  # 0.05 currency units per meter
distance = 100  # meters
toll = toll_calculator.calculate_toll(distance)
print(f"Toll for {distance} meters is {toll} currency units")
