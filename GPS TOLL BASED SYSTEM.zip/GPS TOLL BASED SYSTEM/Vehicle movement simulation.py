import random

class Vehicle:
    def __init__(self, id, route):
        self.id = id
        self.route = route  # List of GPS coordinates (lat, lon)
        self.current_position = 0

    def move(self):
        if self.current_position < len(self.route) - 1:
            self.current_position += 1

    def get_position(self):
        return self.route[self.current_position]