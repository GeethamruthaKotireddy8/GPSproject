from geopy.distance import geodesic

def calculate_distance(coord1, coord2):
    return geodesic(coord1, coord2).meters

# Example usage:
coord1 = (12.9715987, 77.594566)
coord2 = (12.9716192, 77.594647)
distance = calculate_distance(coord1, coord2)
print(f"Distance between {coord1} and {coord2} is {distance} meters")
