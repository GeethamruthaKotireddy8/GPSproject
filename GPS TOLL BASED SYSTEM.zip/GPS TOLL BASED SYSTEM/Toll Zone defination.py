class TollZone:
    def __init__(self, id, coordinates):
        self.id = id
        self.coordinates = coordinates  # GPS coordinates (lat, lon)

# Example usage:
toll_zones = [
    TollZone(1, (12.9715987, 77.594566)),
    TollZone(2, (12.9716192, 77.594647))
]

for zone in toll_zones:
    print(f"Toll Zone {zone.id} at coordinates {zone.coordinates}")